<?php
class SuspiciousPage extends CMSWebPageBase{

	function doPost(){
		if(soy2_check_token()){
			$this->jump("NotFound.Suspicious");
		}
	}

	function __construct(){
		if(!UserInfoUtil::isDefaultUser()){
    		$this->jump("");
		}

		SOY2::import("util.AccessLogUtil");
		
		parent::__construct();

		$this->createAdd("ip_list", "_common.Log.SuspiciousIpAddressListComponent", array(
			"list"	=> SOY2DAOFactory::create("admin.IpAddressDAO")->getSuspiciousIpAddressList()
		));
	}
}
