<?php

class TrimmingAction extends SOY2Action{

    function execute($rsp,$form,$req) {}
}
