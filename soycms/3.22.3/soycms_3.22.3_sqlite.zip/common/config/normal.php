<?php
if(!defined("SOYCMS_TARGET_DIRECTORY")) define("SOYCMS_TARGET_DIRECTORY", rtrim($_SERVER["DOCUMENT_ROOT"], "/")."/");
