<?php
include("./webapp/conf/admin.conf.php");
SOY2PageController::run();
?>
