<?php
/**
 * 顧客入力項目 一覧
 */
class NotationPage extends WebPage{

	function __construct(){
		SOY2PageController::jump("Site");
		exit;
//		parent::__construct();
	}

}
