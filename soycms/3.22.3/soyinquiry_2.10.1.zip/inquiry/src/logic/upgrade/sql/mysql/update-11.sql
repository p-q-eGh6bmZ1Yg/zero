ALTER TABLE soyinquiry_inquiry MODIFY COLUMN ip_address VARCHAR(40);
ALTER TABLE soyinquiry_ban_ip_address MODIFY COLUMN ip_address VARCHAR(40);
