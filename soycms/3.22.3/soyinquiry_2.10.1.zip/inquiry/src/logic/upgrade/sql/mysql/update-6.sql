ALTER TABLE soyinquiry_inquiry MODIFY content TEXT;
ALTER TABLE soyinquiry_inquiry MODIFY data TEXT;
