ALTER TABLE soyinquiry_inquiry ADD COLUMN ip_address VARCHAR;
