create unique index soyinquiry_comment on soyinquiry_comment(inquiry_id, create_date);
create unique index soyinquiry_inquiry on soyinquiry_inquiry(form_id, create_date);
