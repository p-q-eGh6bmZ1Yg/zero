ALTER TABLE soyinquiry_inquiry ADD COLUMN tracking_number VARCHAR(512);
