ALTER TABLE soyinquiry_inquiry ADD COLUMN ip_address VARCHAR(15) AFTER form_id;
