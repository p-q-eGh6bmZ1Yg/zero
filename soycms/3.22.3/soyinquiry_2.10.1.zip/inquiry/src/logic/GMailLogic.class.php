<?php
require_once CMS_COMMON.'lib/vendor/autoload.php';

class GMailLogic extends SOY2LogicBase {

	function __construct(){
		SOY2::import("util.SOYInquiryUtil");
	}
	
	/**
	 * 一通送信する
	 *
	 * @param String sendTo
	 * @param String title
	 * @param String body
	 * @param String sendToName
	 * @param String from
	 * @param String fromName
	 * @param <String> replyTo
	 */
	function sendMail(string $sendTo, string $title, string $body, string $sendToName="", string $from="", string $fromName,  array $replyTo=array()){
		// OAuthクライアントID の秘密鍵ファイルが見つからない場合は終了
		$secretPath = SOYInquiryUtil::SOYINQUIRY_GMAIL_API_OAUTH_CLIENT_SECRET_FILEPATH;
		if(!file_exists($secretPath)) return false;
	
		// 認証トークンが見つからない場合は終了
		$tokenPath = SOYInquiryUtil::SOYINQUIRY_GMAIL_API_OAUTH_TOKEN_FILEPATH;
		if (!file_exists($tokenPath)) return false;
	
		$client = new Google\Client();
		$client->setAuthConfig($secretPath);
		$client->addScope(Google\Service\Gmail::GMAIL_SEND);
		
		$accessToken = json_decode(file_get_contents($tokenPath), true);
		$client->setAccessToken($accessToken);
	
	    // トークンが期限切れならリフレッシュ（自動更新）
		if ($client->isAccessTokenExpired()) {
			if ($client->getRefreshToken()) {
				$client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
	            // 新しいトークンを保存
				file_put_contents($tokenPath, json_encode($client->getAccessToken()));
			} else {
				throw new Exception("リフレッシュトークンがありません。再度ログインが必要です。");
			}
		}

		$service = new Google\Service\Gmail($client);
	    
	    // 日本語（UTF-8）を正しく扱うための構築
	    if(strlen($fromName)){
	    	$strRawMessage = "From: =?utf-8?B?".base64_encode($fromName)."?= <".$from.">\r\n";	
	    }else{
	    	// 「me」は自分のアドレスを指します
			$strRawMessage = "From: me\r\n"; 
	    }
	    
		if(strlen($sendToName)){
			$strRawMessage .= "To: =?utf-8?B?".base64_encode($sendToName)."?= <".$sendTo.">\r\n";
		}else{
			$strRawMessage .= "To: ".$sendTo."\r\n";
		}
		if(count($replyTo)){
			$strRawMessage .= "Reply-To: ".implode(",", $replyTo)."\r\n";
		}
	    $strRawMessage .= "Subject: =?utf-8?B?" . base64_encode($title) . "?=\r\n";
	    $strRawMessage .= "MIME-Version: 1.0\r\n";
	    $strRawMessage .= "Content-Type: text/plain; charset=utf-8\r\n";
	    $strRawMessage .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
	    $strRawMessage .= $body;
	
	    // 5. Base64URL エンコード
	    $mime = rtrim(strtr(base64_encode($strRawMessage), '+/', '-_'), '=');
	    
	    $msg = new Google\Service\Gmail\Message();
	    $msg->setRaw($mime);
	
	    try {
	        // 6. 送信実行
	        $service->users_messages->send('me', $msg);
	        return true;
	    } catch (Exception $e) {
			echo 'エラー: ' . $e->getMessage();
	        return false;
	    }
	}	
}
