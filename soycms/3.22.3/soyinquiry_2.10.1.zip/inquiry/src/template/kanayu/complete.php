<?php $message = $config->getMessage(); echo $message["complete"]; ?>
