<?php

class IndexPage extends WebPage{

    function __construct() {
    	parent::__construct();
    }
}
