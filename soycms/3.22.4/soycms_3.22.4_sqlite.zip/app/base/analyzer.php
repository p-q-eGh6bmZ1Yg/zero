<?php
include_once(CMS_APPLICATION_WEBAPP . "analyzer/layout/MainLayoutPage.class.php");
$page = SOY2HTMLFactory::createInstance("MainLayoutPage");
$page->display();
