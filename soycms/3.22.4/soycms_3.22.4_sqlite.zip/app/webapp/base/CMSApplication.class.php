<?php
//change directory
include_once(dirname(dirname(dirname(__FILE__))) . "/base/CMSApplication.class.php");