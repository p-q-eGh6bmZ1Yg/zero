<?php
/*
 * SOYCMSの多言語ファイル
 * キーが日本語
 */
CMSUtil::Text(array(
	
	"[無題]" => "[no title]",
	"[メモ]" => "[memo]"

));

?>
