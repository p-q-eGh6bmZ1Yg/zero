<?php
/*
 * ダミーです。
 */
CMSUtil::Text(array());
?>
