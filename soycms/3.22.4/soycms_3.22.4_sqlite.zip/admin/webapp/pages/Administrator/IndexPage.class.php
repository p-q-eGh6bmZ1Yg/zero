<?php
echo "URL短縮の為 AdminostratorはAdminにリネーム";
exit;