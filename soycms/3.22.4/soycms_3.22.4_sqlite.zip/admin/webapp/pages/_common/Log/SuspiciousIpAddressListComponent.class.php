<?php

class SuspiciousIpAddressListComponent extends HTMLList{

	protected function populateItem($entity){

		$this->addLabel("ipv4", array(
			"text" => (isset($entity["v4"])) ? $entity["v4"] : ""
		));
	}
}
